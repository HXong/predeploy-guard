import { requestText } from "../../shared/api/http";

export function getMarkdownReport(runId: string): Promise<string> {
  return requestText(`/reports/${encodeURIComponent(runId)}/markdown`);
}
